<?php defined('BASEPATH') OR exit('No direct script access allowed');
// Auto-generated secrets - do not commit to version control.
return array (
  'encryption_key' => '17632bf9b31669238ca944fbf2e1325ddad3684aaff014c6a5ecd1fbf0428478',
  'auth_secret' => '1acec19f67db8fe0aa9fd449833b801577f4833ba03f095f8724ace86bc7f894',
);
