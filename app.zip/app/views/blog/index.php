<?php /** @var array $rows */ ?>
<section class="bg-gradient-to-br from-ink-900 via-ink-800 to-brand-900 text-white">
    <div class="container mx-auto px-4 py-12">
        <h1 class="text-4xl font-extrabold">Blog &amp; insights</h1>
        <p class="text-white mt-2 max-w-2xl">Engineering articles, selection guides and industry insights from our team.</p>
    </div>
</section>
<section class="container mx-auto px-4 py-12">
    <?php if (empty($rows)): ?>
        <p class="text-ink-800 text-center py-12">No articles published yet.</p>
    <?php else: ?>
        <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
            <?php foreach ($rows as $p): ?>
                <a href="<?= base_url('blog/' . $p['slug']) ?>" class="bg-white border rounded-2xl overflow-hidden hover:shadow-lg transition flex flex-col">
                    <div class="aspect-[16/9] bg-gray-100 overflow-hidden"><img src="<?= vp_safe_html(vp_blog_image($p)) ?>" alt="<?= vp_safe_html($p['title']) ?>" class="w-full h-full object-cover hover:scale-105 transition duration-500" loading="lazy" decoding="async" onerror="this.onerror=null;this.src='<?= IMG_URL ?>products/default.jpg'"></div>
                    <div class="p-5 flex-1 flex flex-col">
                        <div class="text-xs text-ink-800"><?= vp_human_date($p['publishedAt']) ?> &middot; <?= (int) $p['views'] ?> views</div>
                        <h3 class="font-bold text-lg text-ink-900 mt-2"><?= vp_safe_html($p['title']) ?></h3>
                        <p class="text-sm text-ink-800 mt-2 flex-1"><?= vp_safe_html(vp_truncate($p['excerpt'] ?? $p['content'], 140)) ?></p>
                        <span class="text-brand-600 text-sm font-semibold mt-3">Read article &rarr;</span>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
        <div class="mt-8 flex justify-center"><?= vp_pagination_links($total_pages, $page, $base_url) ?></div>
    <?php endif; ?>
</section>
