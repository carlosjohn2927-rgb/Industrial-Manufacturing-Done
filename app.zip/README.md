# Vortex Precision — on CodeIgniter 3

**Industrial manufacturing platform** built as a traditional PHP MVC application on **CodeIgniter 3.1.13** with **MySQL / MariaDB**.

This is a full conversion of the original Next.js + NestJS + Prisma + PostgreSQL stack. Every public page, every admin screen, and the hardened RFQ system have been ported to a single deployable PHP application that runs on a typical LAMP / cPanel host — no Composer, no Node, no Docker required.

## Stack

- **CodeIgniter 3.1.13** (vendored under `app/system/`, no Composer)
- **PHP 7.4+ / 8.x** with `password_hash`, `random_bytes`, and PDO/MySQLi
- **MySQL 5.7+ / MariaDB 10.2+** (uses `JSON` columns and `ENUM` types)
- **Apache + mod_php** (or Nginx + PHP-FPM)
- **No JavaScript build step.** Tailwind, Chart.js, TinyMCE, flatpickr, jQuery, Remix Icons all loaded via CDN.
- **Session storage** in the database (`ci_sessions` table).

## Quick start

```bash
# 1. Create a MySQL/MariaDB database in cPanel.
# 2. Configure app/.env from .env.example
#    (VP_DB_* credentials, VP_ENCRYPTION_KEY/VP_AUTH_SECRET secrets,
#     optional RESEND_API_KEY, first admin account).
# 3. Install schema + seed + admin account (CLI only; tooling lives
#    OUTSIDE the web root):
php install/install.php
#    (manual alternative: import install/install.sql + install/seed.sql
#     in phpMyAdmin, then `php install/install.php --users-only`)

# 4. Point your domain's document root at the `app/` directory.
#    In cPanel: set "Document root" to the full path of the `app/` folder.

# 5. Browse https://your-domain.com
```

There is **no default administrator password**. The installer creates the
admin with your `VP_ADMIN_PASSWORD`, or with a random temporary password
printed once and a forced password change on first login.

## Local development (no Apache required)

```bash
# Requires PHP 7.4+ and a local MySQL/MariaDB (the app will not boot without one).
# Install the database first — see "Quick start" above — then boot the dev server:
./scripts/start.sh
# → http://localhost:8080
```

`scripts/start.sh` launches PHP's built-in server (with `app/tests/router.php`); it
expects an already-installed database and prints a reminder to run the
installer first. Once the DB is installed, the public site and `/admin/login`
are served immediately.

## Project structure

```
app/
├── index.php                 # CodeIgniter front controller
├── .htaccess                 # Apache rewrite + security headers
├── system/                   # CI3 core (vendored, do not edit)
├── application/
│   ├── config/               # CI3 config (database, routes, autoload, constants)
│   ├── controllers/          # Public + admin controllers
│   │   ├── Home.php About.php Services.php Contact.php
│   │   ├── Products.php Industries.php Blog.php Careers.php Faq.php
│   │   ├── Downloads.php News.php Search.php Rfq.php
│   │   ├── Auth.php Errors.php
│   │   └── admin/            # Full admin: Dashboard, Products, Quotes, Users, …
│   ├── core/                 # MY_Controller, Auth_Controller, Admin_Controller, Admin_Crud
│   ├── libraries/            # Vp_auth, Rbac, Settings, Mailer, Audit, Rate_limiter, Vp_upload
│   ├── helpers/              # app_helper, security_helper
│   ├── models/               # One model per DB table
│   └── views/                # Layouts, partials, public + admin views
├── assets/                   # CSS / JS / img / uploads / logs
│   ├── uploads/              # Runtime uploads (execution denied via .htaccess)
│   └── logs/                 # App logs + cache + rate-limit buckets (web access denied)
└── tests/                    # Acceptance suite + dev-server router (web access denied)
```

```
install/                      # install.sql, seed.sql, install.php (CLI, OUTSIDE the web root)
.env.example                  # All environment variables, documented
.github/workflows/            # CI acceptance suite (PHP 8.2/8.3 x MySQL 8.0/MariaDB 10.6)
scripts/                      # Local/dev utilities (start server, smoke checks)
```

## What works today

**Public site (server-rendered)**
- Home, About, Services, Contact
- Products list + detail (search, category/industry filters, pagination, related products, specs, downloads)
- Industries list + detail
- Blog list + post
- Careers list + detail + apply (with file upload)
- FAQ (grouped, accordion)
- Downloads (with counter)
- News list + item
- Search (products + articles + FAQs)
- Login / register / logout / forgot / reset
- **RFQ form** with line items, file-upload, rate limiting, idempotent emails

**Admin (`/admin`)**
- Dashboard with chart (quote counts by status, recent activity)
- **Quotes** — list with filters, single-quote view with items/history/activity timeline, status update with state-machine + optimistic lock, internal notes, assign, generate printable PDF, CSV export
- Products, Categories, Industries, Downloads — full CRUD
- Blog, Careers, News — CRUD
- Contacts — list + view + reply + delete
- FAQs, Testimonials, Partners — CRUD
- Users (RBAC)
- Settings (key-value editor)
- Media library (uploads with resize)
- Audit log
- Notifications
- Login / logout (separate endpoint, redirects based on role)

**Hardened RFQ system** (ported from the NestJS implementation)
- Forward-only state machine: NEW → REVIEWING → QUOTED → APPROVED/REJECTED → COMPLETED
- Optimistic locking via `version` column (409 on stale update)
- Required `assignedTo` to leave NEW
- Status history + activity timeline per quote
- **Idempotent emails** via `email_logs.dedupe_key`
- Rate limit: 5 RFQ / hour per IP+email
- Global 100 requests / 15 min per IP

**Security**
- CSRF tokens on every POST
- `password_hash()` (BCRYPT) + `password_verify()`
- HMAC-signed remember-me cookie
- Login attempt throttling (5 / 15 min)
- DB-backed sessions
- Security headers (X-Frame-Options, CSP, etc.) in `.htaccess`
- Upload directory: PHP execution denied via `.htaccess`

## Where to look

- Routes: `app/application/config/routes.php`
- SQL schema: `install/install.sql`
- Seed data: `install/seed.sql` (content only — **no user accounts**)
- Installer: `install/install.php` (creates the first admin, env-driven password)
- Environment template: `.env.example`
- Acceptance suite: `app/tests/acceptance.php` + `.github/workflows/acceptance.yml`
- Old NestJS endpoint → new route map: `docs/API_MAP.md`
- Full admin usage: `docs/ADMIN_GUIDE.md`
- cPanel install steps: `docs/INSTALLATION.md`
- Production hardening: `docs/DEPLOYMENT.md`
- RFQ system details: `docs/RFQ.md`

## Accounts & credentials

No accounts are shipped with the repository. `install/install.php` creates
the first SUPER_ADMIN (email from `VP_ADMIN_EMAIL`, default
`admin@vortexprecision.com`) with a password from `VP_ADMIN_PASSWORD` or a
random temporary password that must be changed on first login. Additional
staff accounts are created via `/admin/users`.

## Licence

Copyright Vortex Precision. All rights reserved.
