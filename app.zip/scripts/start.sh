#!/bin/bash
# Vortex Precision - start the CodeIgniter 3 app under PHP's built-in server.
# Binds to 0.0.0.0:8080 for the live preview.
set -e
cd "$(dirname "$0")/../app"
PORT="${PORT:-8080}"
HOST="${HOST:-0.0.0.0}"
echo "Starting Vortex Precision (CodeIgniter 3) at http://${HOST}:${PORT}"
echo "Document root: $(pwd)"
echo ""
echo "Make sure your MySQL/MariaDB is running and you've installed the app:"
echo "  1. Set DB + secret env vars (see .env.example, or export VP_DB_* directly)"
echo "  2. php ../install/install.php   (schema + seed + admin account)"
echo ""
php -S "${HOST}:${PORT}" -t . tests/router.php
